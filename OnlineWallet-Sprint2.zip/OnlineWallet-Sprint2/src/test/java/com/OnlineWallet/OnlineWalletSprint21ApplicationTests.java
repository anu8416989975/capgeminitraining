package com.OnlineWallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineWalletSprint21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
