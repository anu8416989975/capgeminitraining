package com.cg.onlinewallet.exceptions;

public class InvalidException extends RuntimeException {

	public InvalidException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
