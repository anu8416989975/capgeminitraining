package com.cg.onlinewallet.exceptions;

public class ValidationException extends RuntimeException {

	public ValidationException() {
		// TODO Auto-generated constructor stub
	}

	public ValidationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
