package com.cg.onlinewallet.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.onlinewallet.dao.*;
import com.cg.onlinewallet.entities.*;
import com.cg.onlinewallet.entities.Account.status;
import com.cg.onlinewallet.entities.User.type;
import com.cg.onlinewallet.exceptions.*;

@Transactional
@Service
public class OnlineWalletServiceImp implements OnlineWalletService {

	public OnlineWalletServiceImp() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private OnlineWalletDao onlineWalletDao;

	
	/*********************************************************************************************************************
	 * Method: loginAdmin Description: To Validate the Admin data so that the Admin
	 * can login
	 * 
	 * @param email:
	 *            Admin's LoginName
	 * @param password:
	 *            Admin's password
	 * @returns Integer: userId associated with the loginName provided if no
	 *          exceptions occurs
	 * @throws UnauthorizedAccessException:it
	 *             is raised if the account associated with loginName is not an
	 *             admin type
	 * @throws ValidationException:
	 *             it is raised if the password dosen't matches with the user's
	 ***********************************************************************************************************************/
	@Override
	public Integer loginAdmin(String email, String password) {
		if(!onlineWalletDao.checkUserByEmail(email))
			throw new UnauthorizedAccessException("No Admin exist for this email address. Kindly ask administration to get yourself registered");
		User user = onlineWalletDao.getUserByEmail(email);
		if (user.getUserType() == type.user)
			throw new UnauthorizedAccessException("You are not authorized to login from here");
		if (user.getPassword().equals(password) == false)
			throw new ValidationException("The LoginName and password Combination does not match");
		return user.getUserID();
	}

	/*********************************************************************************************************************
	 * Method: getUserList Description: To return the list of loginNames of the user
	 * according to userstatus provided
	 * 
	 * @param adminId:
	 *            Admin's userId
	 * @param userstatus:
	 *            user status
	 * @returns List<String>: List containing the loginNames of the user based on
	 *          their userStatus. either active or non_active
	 * @throws UnauthorizedAccessException:it
	 *             is raised if the account associated with adminId is not an admin
	 *             type
	 * @throws WrongValueException:it
	 *             is raised if the variable userStatus is other then values active
	 ***********************************************************************************************************************/
	@Override
	public List<String> getUserList(Integer adminId, String userStatus) {

		User admin = onlineWalletDao.getUser(adminId);
		if (admin.getUserType() == type.user)
			throw new UnauthorizedAccessException("You are not authorized to perform this task");
		if (userStatus.equalsIgnoreCase(new String("non_active")))
			return onlineWalletDao.getNonActiveUserList();
		else if (userStatus.equalsIgnoreCase(new String("active")))
			return onlineWalletDao.getActiveUserList();
		throw new WrongValueException("not a criteria to fetch user details");
	}

	/*********************************************************************************************************************
	 * Method: changeUserStatus Description: Changes the status of account of user
	 * from active to non-active and other-way around
	 * 
	 * @param adminId:
	 *            Admin's userId
	 * @param email:
	 *            User's email whose status has to be changed
	 * @param userstatus:
	 *            user status
	 * @throws UnauthorizedAccessException:
	 *             if the user associated with adminId is not a admin type
	 * @throws InvalidException:
	 *             it is raised if there is no user associated with the login name
	 *             provided
	 * @throws UnauthorizedAccessException:
	 *             it is raised if the user associated with the login name is admin
	 *             type
	 * @throws WrongValueException:
	 *             it is raised if the variable userStatus is other then values
	 ***********************************************************************************************************************/
	@Override
	public String changeUserStatus(Integer adminId, String email, String userStatus) {

		User admin = onlineWalletDao.getUser(adminId);
		if (admin.getUserType() == type.user)
			throw new UnauthorizedAccessException("You are Authorized to perform this task");
		if (onlineWalletDao.checkUserByEmail(email) == false)
			throw new InvalidException("There is no user with this LoginName. Please Enter a valid LoginName");
		User user = onlineWalletDao.getUserByEmail(email);
		if (user.getUserType() == type.admin)
			throw new UnauthorizedAccessException("Can't perform Task, Unauthorized Access");
		if (userStatus.equals(new String("non_active")))
			user.getAccountDetail().setUserStatus(status.non_active);
		else if (userStatus.equals(new String("active"))) {
			user.getAccountDetail().setUserStatus(status.active);
		} else
			throw new WrongValueException("The Status code does not exist");
		return user.getEmail();
	}

	
}
