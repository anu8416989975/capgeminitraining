package com.cg.onlinewallet.exceptions;

public class WrongValueException extends RuntimeException {

	public WrongValueException() {
		// TODO Auto-generated constructor stub
	}

	public WrongValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
